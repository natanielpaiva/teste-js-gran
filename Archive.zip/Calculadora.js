//me siga @natanieltech
// Calculadora.js
class Calculadora {
    adicionar(a, b) {
      return a + b;
    }
  
    subtrair(a, b) {
      return a - b;
    }
  }
  
module.exports = Calculadora;
  